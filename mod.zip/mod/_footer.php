<?php

if (!defined('GOT_CONFIG')) {
    die('No direct file access.');
}

?>



			</div>
		</div>
	</div>
</body>
</html>